import os
import json
import pandas as pd
import re
import glob


def clean_segment(segment: str) -> str:
    """
    Sanitize the segment string so it can be safely used as part of a file name:
      - Replace non-breaking spaces with regular spaces
      - Remove characters illegal in Windows file names: \ / * ? : " < > |
      - Replace spaces with dashes and convert to lower case
    """
    segment = segment.replace(u'\xa0', ' ')
    segment = re.sub(r'[\\/*?:"<>|]', '', segment)
    return segment.strip().lower().replace(" ", "-")


def process_solaris_esgs():
    """
    Process Excel files to generate ESG configurations for each worksheet
    """
    # Directory containing your XLSX files
    xlsx_dir = r"C:\Users\kiman\Documents\GitHub\PAAS5500\src\esg-segs"
    xlsx_files = glob.glob(os.path.join(xlsx_dir, "*.xlsx"))

    if not xlsx_files:
        print(f"No XLSX files found in {xlsx_dir}")
        return

    print("\nStarting ESG processing...")
    print(f"Found {len(xlsx_files)} Excel files in {xlsx_dir}")

    files_processed = 0
    worksheets_processed = 0
    esgs_generated = 0

    output_base_dir = r"C:\Users\kiman\Documents\GitHub\PAAS5500\src\configurations"
    os.makedirs(output_base_dir, exist_ok=True)

    for file_path in xlsx_files:
        base_file_name = os.path.splitext(os.path.basename(file_path))[0]
        print(f"\nProcessing file: {file_path}")

        try:
            # Get all worksheet names
            xl = pd.ExcelFile(file_path)
            worksheets = xl.sheet_names

            # Remove 'ESG Overview' from the list of worksheets to process
            if "ESG Overview" in worksheets:
                # Read ESG Overview to get mapping of worksheet names to ESG names
                overview_df = pd.read_excel(
                    file_path, sheet_name="ESG Overview")
                worksheets.remove("ESG Overview")

            worksheets_processed += len(worksheets)

            # Process each worksheet
            for sheet in worksheets:
                print(f"\nProcessing worksheet: {sheet}")
                df = pd.read_excel(file_path, sheet_name=sheet)

                # Clean column names and print them for debugging
                df.columns = df.columns.str.strip()
                print("Available columns:", df.columns.tolist())

                # Look for IP Address column with case-insensitive match
                ip_column = None
                for col in df.columns:
                    if col.lower() == 'ip address':
                        ip_column = col
                        break

                if not ip_column:
                    print(
                        f"Warning: No 'IP Address' column found in worksheet '{sheet}'. Skipping...")
                    continue

                # Derive ESG name from the worksheet data
                esg_name = clean_segment(sheet)

                # Gather unique IP addresses and remarks
                ips = df[ip_column].dropna().unique().tolist()
                ips = [ip.strip() + "/32" for ip in ips if ip.strip() != ""]

                # Look for Remark column with case-insensitive match
                remark_column = None
                for col in df.columns:
                    if col.lower() == 'remark':
                        remark_column = col
                        break

                if remark_column:
                    remarks = df[remark_column].dropna().unique().tolist()
                    annotation = "; ".join(
                        remarks) if remarks else "No Description Provided"
                else:
                    annotation = "No Description Provided"

                # Build the ESG JSON structure
                esg_object = {
                    "fvESg": {
                        "attributes": {
                            "name": esg_name,
                            "descr": f"ESG for endpoints - {annotation}",
                            "dn": f"uni/tn-all-ESG/ap-ap-ESG-01/esg-esg-{esg_name}",
                            "annotation": f"ESG - {annotation}",
                            "floodOnEncap": "disabled",
                            "matchT": "AtleastOne",
                            "pcEnfPref": "unenforced",
                            "prefGrMemb": "exclude",
                            "prio": "unspecified",
                            "shutdown": "no",
                            "userdom": ":all:"
                        },
                        "children": [
                            {
                                "fvTagSelector": {
                                    "attributes": {
                                        "annotation": annotation,
                                        "descr": f"ESG IP Selector for endpoints for ESG: {esg_name}",
                                        "dn": f"uni/tn-all-ESG/ap-ap-ESG-01/esg-esg-{esg_name}/selector-{esg_name}",
                                        "ip": ", ".join(ips),
                                        "name": esg_name,
                                        "valueOperator": "equals",
                                        "userdom": ":all:"
                                    }
                                }
                            },
                            {
                                "fvRsScope": {
                                    "attributes": {
                                        "tnFvCtxName": "PROD",
                                        "userdom": ":all:"
                                    }
                                }
                            },
                            {
                                "fvRsProv": {
                                    "attributes": {
                                        "tnVzBrCPName": "vzany",
                                        "annotation": "ESG provides contract vzany",
                                        "userdom": ":all:"
                                    }
                                }
                            }
                        ]
                    }
                }

                # Create output file
                output_file_name = f"{base_file_name}-esg-esg-{esg_name}.json"
                output_file = os.path.join(output_base_dir, output_file_name)
                os.makedirs(os.path.dirname(output_file), exist_ok=True)

                with open(output_file, "w") as f:
                    json.dump(esg_object, f, indent=2)

                print(
                    f"Wrote ESG configuration for worksheet '{sheet}' to: {output_file}")

                # After successful ESG generation
                esgs_generated += 1

        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            continue

        files_processed += 1

    # Print summary at the end
    print("\n=== Processing Summary ===")
    print(f"Files processed: {files_processed}")
    print(f"Worksheets processed: {worksheets_processed}")
    print(f"ESGs generated: {esgs_generated}")
    print("========================")


if __name__ == "__main__":
    process_solaris_esgs()
