import os
import json
import pandas as pd
import re

# Function to sanitize the segment name for use in a filename.


def clean_segment(segment: str) -> str:
    # Convert non-breaking spaces to regular spaces
    segment = segment.replace(u'\xa0', ' ')
    # Remove Windows-invalid characters: \ / * ? : " < > |
    segment = re.sub(r'[\\/*?:"<>|]', '', segment)
    # Replace remaining spaces with dashes and convert to lower case
    return segment.strip().lower().replace(" ", "-")


# Read the Excel file using the updated file path.
file_path = r"C:\Users\kiman\Documents\GitHub\PAAS5500\src\esg-segs\solaris_10_esg_groups.xlsx"
df = pd.read_excel(file_path)

# Filter for Solaris 10 endpoints only.
# (Assumes that the "Type" column exactly equals "Solaris 10" for target rows.
#  Adjust as necessary if trimming or case-insensitive matching is needed.)
df_solaris10 = df[df["Type"].str.strip() == "Solaris 10"]

# Group by the Proposed segment (Column I)
groups = df_solaris10.groupby("Proposed segment")

# Iterate over each group to build the ESG configuration.
for segment, group_df in groups:
    # Skip if Proposed segment is empty or NaN
    if pd.isna(segment) or segment.strip() == "":
        continue

    # Gather all unique IP addresses from Column C and append /32 if not already present.
    ips = group_df["IP Address"].dropna().unique().tolist()
    ips = [ip.strip() + "/32" for ip in ips if ip.strip() != ""]

    # Extract unique values from the Remark column (Column B). You can join them if more than one.
    remarks = group_df["Remark"].dropna().unique().tolist()
    annotation = "; ".join(remarks) if remarks else "No Description Provided"

    # Use the new clean_segment function to build a normalized ESG name.
    esg_name = clean_segment(segment)

    # Build the ESG object payload.
    esg_object = {
        "fvESg": {
            "attributes": {
                "name": esg_name,
                "descr": f"ESG for Solaris10 endpoints - {annotation}",
                "dn": f"uni/tn-all-ESG/ap-ap-ESG-01/esg-esg-{esg_name}",
                "annotation": f"ESG for Solaris10 - {annotation}",
                "floodOnEncap": "disabled",
                "matchT": "AtleastOne",
                "pcEnfPref": "unenforced",
                "prefGrMemb": "exclude",
                "prio": "unspecified",
                "shutdown": "no",
                "userdom": ":all:"
            },
            "children": [
                {
                    "fvTagSelector": {
                        "attributes": {
                            "annotation": annotation,
                            "descr": f"ESG IP Selector for Solaris 10 endpoints for ESG: {esg_name}",
                            "dn": f"uni/tn-all-ESG/ap-ap-ESG-01/esg-esg-{esg_name}/selector-{esg_name}",
                            "ip": ", ".join(ips),
                            "name": esg_name,
                            "valueOperator": "equals",
                            "userdom": ":all:"
                        }
                    }
                },
                {
                    "fvRsScope": {
                        "attributes": {
                            "tnFvCtxName": "PROD",
                            "userdom": ":all:"
                        }
                    }
                },
                {
                    "fvRsProv": {
                        "attributes": {
                            "tnVzBrCPName": "vzany",
                            "annotation": "ESG provides contract vzany",
                            "userdom": ":all:"
                        }
                    }
                }
            ]
        }
    }

    # Determine output file path.
    output_file = f"src/configurations/esg-esg-solaris-{esg_name}.json"
    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    # Write the JSON file.
    with open(output_file, "w") as f:
        json.dump(esg_object, f, indent=2)

    print(f"Wrote ESG configuration for segment '{segment}' to: {output_file}")
